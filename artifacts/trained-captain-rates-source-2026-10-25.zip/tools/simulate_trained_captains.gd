extends "res://tools/simulate_auto_runs.gd"
# Equal 105XP shared kit; one identity-independent support-aware study policy.
const Training=preload("res://tools/captain_training_plan.gd")
const CombatPolicy=preload("res://tools/relic_mix_simulation.gd")
var combat_policy=CombatPolicy.new()
class StudyCampaign:
 extends "res://game/campaign.gd"
 func save_game() -> bool:return true
 func sync_achievements():pass
func play(b) -> Dictionary:
 var steps=0
 var error=""
 while b.outcome=="" and steps<2000:
  if not combat_policy.step(b):error="invalid study action";break
  steps+=1
 if b.outcome=="" and error=="":error="step limit"
 var outcome={"outcome":b.outcome,"steps":steps,"rounds":b.round_no,"error":error}
 outcome["captain_talent_activations"]={
  "shen":b.events.filter(func(event):return "余烬接力 · 进军号令" in event).size(),
  "wen":b.events.filter(func(event):return "归途之约 · 保护同伴" in event).size(),
  "lu":b.events.filter(func(event):return "异式演算 · 法力+4" in event).size()}
 outcome["shen_followups"]=b.events.filter(func(event):return "余烬接力 · 伤害+4" in event).size()
 var hero=b.find_actor("hero")
 outcome["captain_hp"]=hero.hp
 outcome["captain_mp"]=hero.mp
 return outcome
func run():
 var captain="shen"
 var level=0
 var count=1000
 var seed_start=2026102500
 var label="main"
 var disk_saves=false
 for arg in OS.get_cmdline_user_args():
  if arg.begins_with("--captain="):captain=arg.trim_prefix("--captain=")
  if arg.begins_with("--difficulty="):level=int(arg.trim_prefix("--difficulty="))
  if arg.begins_with("--count="):count=int(arg.trim_prefix("--count="))
  if arg.begins_with("--seed-start="):seed_start=int(arg.trim_prefix("--seed-start="))
  if arg.begins_with("--label="):label=arg.trim_prefix("--label=")
  if arg=="--disk-saves":disk_saves=true
 if captain not in Campaign.Characters.CAPTAINS or level not in [0,1,2,3] or count<1 or count>100000 or not label.is_valid_identifier():
  push_error("invalid study parameters");quit(1);return
 var hashes={}
 for source in DirAccess.get_files_at("res://game"):
  if source.ends_with(".gd"):hashes[source]=FileAccess.get_sha256("res://game/"+source)
 var policy_hashes={}
 for source in ["simulate_auto_runs.gd","simulate_trained_captains.gd","captain_training_plan.gd","relic_mix_simulation.gd"]:policy_hashes[source]=FileAccess.get_sha256("res://tools/"+source)
 var temporary_save="user://difficulty-study-%d-%d.json"%[level,Time.get_ticks_usec()]
 var results=[]
 var started=Time.get_ticks_msec()
 for index in range(count):
  var c=Campaign.new(temporary_save) if disk_saves else StudyCampaign.new(temporary_save)
  c.rng.seed=seed_start+index
  c.overall_difficulty=level
  var captain_selected=c.select_captain(captain)
  var row={"captain":captain,"seed":seed_start+index,"difficulty":level,"cleared":false,"failure":"","battles":[]}
  if not captain_selected:row.failure="captain selection rejected"
  var training=Training.apply(c)
  row["training"]=training
  if training.error!="":row.failure=training.error
  if not c.completed_difficulties.is_empty():row.failure="unexpected achievement bonuses"
  for pair in [[0,"hero"],[1,"blade"],[2,"ranger"],[3,"medic"],[4,"engineer"],[5,"hero"],[6,"blade"]]:
   if not c.equip_item(pair[0],pair[1]):row.failure="equipment rejected"
  var hero=c.roster.filter(func(unit):return unit.id=="hero")[0]
  row["initial_captain"]={"character_id":hero.character_id,"hp":hero.hp,"mp":hero.mp,"power":hero.power,"armor":hero.armor,"speed":hero.speed,"range":hero.range,"xp":hero.xp,"skill_ranks":hero.skill_ranks.duplicate(true)}
  if not c.start_region("border"):row.failure="region rejected"
  row["route_seed"]=c.route.seed_value
  for depth in range(c.route.nodes[-1].depth+1):
   if row.failure!="":break
   var available=c.route.available()
   if available.is_empty():row.failure="unfinished route";break
   var selected=c.route.node(available[0])
   for id in available:
    var node=c.route.node(id)
    if node.kind=="battle":selected=node;break
    if node.kind=="supply":selected=node
   if not c.enter_route(selected.id):row.failure="route rejected";break
   if selected.kind=="battle":
    var ids=PARTY.filter(func(id):return c.roster.any(func(unit):return unit.id==id and unit.hp>0))
    var b=c.make_battle(ids,selected.encounter)
    if b==null:row.failure="deployment rejected";break
    var outcome=play(b)
    outcome["survivors"]=b.actors.filter(func(actor):return actor.side==0 and actor.hp>0).size()
    outcome["party_hp"]=0
    for actor in b.actors:
     if actor.side==0:outcome.party_hp+=maxi(0,actor.hp)
    outcome["supplies_remaining"]=c.supplies
    outcome["depth"]=depth
    outcome["threat"]=selected.threat
    row.battles.append(outcome)
    if outcome.error!="":row.failure=outcome.error;break
    if not c.resolve_battle(b):row.failure="settlement rejected";break
    if b.outcome!="victory":row.failure=b.outcome;break
    var reward=-1
    for i in c.choices.size():
     if c.choices[i].type=="resource":reward=i;break
    if reward<0 or not c.choose_reward(reward):row.failure="reward rejected";break
   if c.phase=="world":
    while c.supplies>0 and c.roster.any(func(unit):return unit.hp>0 and (unit.hp<unit.max_hp*0.7 or unit.mp<unit.max_mp*0.5)):c.use_supply()
   if selected.kind=="extract":
    row.cleared="border" in c.cleared_regions and c.extract([])
    if not row.cleared:row.failure="extraction rejected"
  if not row.cleared and row.failure=="":row.failure="unfinished expedition"
  results.append(row)
  if (index+1)%10==0 or index+1==count:
   print("PROGRESS level=%d completed=%d/%d clears=%d elapsed_ms=%d"%[level,index+1,count,results.filter(func(r):return r.cleared).size(),Time.get_ticks_msec()-started])
   await process_frame
 var changed=[]
 for source in hashes:
  if hashes[source]!=FileAccess.get_sha256("res://game/"+source):changed.append(source)
 for source in policy_hashes:
  if policy_hashes[source]!=FileAccess.get_sha256("res://tools/"+source):changed.append("tools/"+source)
 var report={"label":label,"difficulty":level,"difficulty_name":Campaign.OVERALL_DIFFICULTIES[level],"captain":captain,"captain_name":Campaign.Characters.CATALOG[captain].name,"untrained_reference_rate":[0.40,0.125,0.02,0.0][level],"training_budget":Training.BUDGET,"training_plan":Training.PLAN,"source_hashes":hashes,"policy_hashes":policy_hashes,"changed_sources":changed,"policy":"equal-105XP captain study: shared strike2/hero_heal1/mark1 kit trained through real API; same four basic companions; seven fixed starting gear assignments; prefer battles then supplies; resource rewards only; heal below 70% HP or 50% MP; shared support-aware relic_mix_simulation.step policy, not the Auto button planner; no additional training/shopping/relics/retries or achievement bonuses; defeat boss AND extract to clear","region":"border","seed_start":seed_start,"runs":count,"disk_saves":disk_saves,"elapsed_ms":Time.get_ticks_msec()-started,"clears":results.filter(func(row):return row.cleared).size(),"results":results}
 var out="res://artifacts/trained-captain-rates-%s-%s-%d.json"%[label,captain,level]
 var file=FileAccess.open(out,FileAccess.WRITE)
 if file==null:push_error("could not write study report");quit(1);return
 file.store_string(JSON.stringify(report));file.close()
 for path in [temporary_save,temporary_save+".tmp",temporary_save+".achievements"]:DirAccess.remove_absolute(path)
 var errors=results.filter(func(row):return row.failure not in ["","gameover","defeat"])
 print("TRAINED_CAPTAIN_DONE captain=%s difficulty=%d clears=%d/%d errors=%d changed=%s elapsed_ms=%d"%[captain,level,report.clears,count,errors.size(),changed,report.elapsed_ms])
 quit(0 if errors.is_empty() and changed.is_empty() else 1)
