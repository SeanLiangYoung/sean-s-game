Diagnostic-only runs. Excluded from formal balance statistics: old enemy move handling could stall under snare/AP1. Their mark policy and team gear budgets also differ from the controlled study.
