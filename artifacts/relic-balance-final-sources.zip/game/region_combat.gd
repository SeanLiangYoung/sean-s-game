extends RefCounted
const Regions=preload("res://game/regions.gd")

static func setup(b,unit: Dictionary,biome: String,is_boss: bool):
 var region=Regions.definition(biome)
 var row=region.enemies[0 if unit.range>1 else 1]
 unit.merge({"biome":biome,"archetype":row[0],"trait":region.boss_trait if is_boss else row[1],"boss":is_boss,"statuses":{},"frost_used":false,"venom_used":false,"boss_prepared":false,"turn_serial":0},true)
 unit.name=region.boss if is_boss else row[0]
 renew_barrier(b,unit)

static func renew_barrier(b,unit: Dictionary):
 if unit.hp<=0 or unit.get("statuses",{}).has("exposed"):return
 var amount={"capacitor":6,"core":8,"ice_king":10}.get(unit.get("trait",""),0)
 if amount>0:b.put_status(unit,"shield",unit.id,amount-10)

static func reduction(b,source: Dictionary,target: Dictionary,direct: bool) -> int:
 if not direct:return 0
 var exposed=target.get("statuses",{}).has("exposed")
 match target.get("trait",""):
  "formation":
   if b.actors.any(func(a):return a.hp>0 and a.side==target.side and a.id!=target.id and b.hex_distance(a.cell,target.cell)==1):return 2
  "camouflage":
   if not exposed and not target.get("statuses",{}).has("mark") and b.hex_distance(source.cell,target.cell)>=3:return 4
  "frost_armor":
   if not exposed and not target.get("frost_used",false):
    target.frost_used=true
    return 4
 return 0

static func attack_bonus(unit: Dictionary,target: Dictionary) -> int:
 var bonus=0
 if unit.get("trait","")=="raider" and unit.hp*2<=unit.max_hp:bonus+=3
 if unit.get("trait","")=="ambush" and target.hp==target.max_hp:bonus+=3
 if unit.get("statuses",{}).has("command"):
  bonus+=3
  unit.statuses.erase("command")
 return bonus

static func after_attack(b,source: Dictionary,target: Dictionary,damage: int):
 if damage<=0 or source.hp<=0:return
 if source.get("trait","")=="mirehide":source.hp=mini(source.max_hp,source.hp+int(damage*0.2))
 if target.hp<=0 or source.get("venom_used",false):return
 match source.get("trait",""):
  "spotter":b.put_status(target,"mark",source.id)
  "venom":poison(b,target,source.id)
  "frostshot":b.put_status(target,"chill",source.id)
  "sapper","drainer":target.mp=maxi(0,target.mp-(2 if source.trait=="sapper" else 3))
  _:return
 source.venom_used=true

static func poison(b,target: Dictionary,source: String):
 b.put_status(target,"poison",source,3)
 target.statuses.poison.ticks=2

static func turn_start(b,unit: Dictionary,staggered: bool):
 unit.frost_used=false
 unit.venom_used=false
 unit.boss_prepared=false
 unit.turn_serial=int(unit.get("turn_serial",0))+1
 renew_barrier(b,unit)
 if not unit.get("boss",false):return
 var due=b.boss_intents.filter(func(intent):return intent.source==unit.id and intent.due<=unit.turn_serial)
 for intent in due:
  b.boss_intents.erase(intent)
  if staggered and intent.kind=="overload":
   b.events.append("星核过载被打断 · 监守失去本次蓄力")
   continue
  resolve(b,unit,intent)
  b.check_outcome()
  if b.outcome!="":return

static func prepare(b,boss: Dictionary) -> bool:
 if not boss.get("boss",false) or boss.get("boss_prepared",false) or boss.ap<2:return false
 var targets=b.actors.filter(func(u):return u.side==0 and u.hp>0)
 if targets.is_empty():return false
 targets.sort_custom(func(x,y):
  if boss.biome=="ruins" and x.mp!=y.mp:return x.mp>y.mp
  if x.hp!=y.hp:return x.hp<y.hp
  return str(x.id)<str(y.id))
 var center=targets[0].cell
 var region=Regions.definition(boss.biome)
 var warned=[center]
 if region.kind=="command":
  if targets.size()>1:warned.append(targets[1].cell)
 elif region.kind=="sandline":
  # Pick one of six straight hex axes; a lateral step always leaves the ray.
  var direction=b.DIRS[0]
  var closest=999
  for dir in b.DIRS:
   var distance=b.hex_distance(boss.cell+dir,center)
   if distance<closest:closest=distance;direction=dir
  warned=[]
  for step in range(-2,3):warned.append(center+direction*step)
 else:
  warned.append(center+b.DIRS[1]);warned.append(center+b.DIRS[4])
 warned=warned.filter(func(cell):return b.hex_distance(cell,Vector2i.ZERO)<=b.radius and cell not in b.obstacles)
 if warned.is_empty():warned=[center]
 boss.ap-=2
 boss.boss_prepared=true
 b.boss_intents.append({"source":boss.id,"kind":region.kind,"name":region.intent,"cells":warned,"damage":region.damage,"debuff":region.debuff,"due":boss.turn_serial+1})
 b.events.append("首领预告 · "+region.intent+"：下次自身行动结算，移出危险格")
 return true

static func resolve(b,boss: Dictionary,intent: Dictionary):
 b.events.append("首领施放 · "+intent.name)
 var targets=b.actors.filter(func(u):return u.hp>0 and u.side==0 and u.cell in intent.cells and b.hex_distance(u.cell,Vector2i.ZERO)<=b.radius)
 if intent.kind=="command":
  for target in targets:b.put_status(target,"mark",boss.id)
  var followers=b.actors.filter(func(u):return u.hp>0 and u.side==1 and u.id!=boss.id)
  for follower in followers.slice(0,2):b.put_status(follower,"command",boss.id)
  return
 for target in targets:
  var before=target.hp
  b.deal_damage(boss,target,intent.damage,true)
  if target.hp<=0 or target.hp==before:continue
  if intent.debuff=="poison":poison(b,target,boss.id)
  elif intent.debuff!="":b.put_status(target,intent.debuff,boss.id)
  if intent.kind in ["sandline","overload"]:target.mp=maxi(0,target.mp-(2 if intent.kind=="sandline" else 4))
